<?php

$refresh_token = "token anda";

$min_point = 50;

$max_point = 100;

$email_coinbase = "email anda";

$target_withdraw = 449000;

$version = "13";
